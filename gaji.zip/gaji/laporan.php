<?php
include "header.php";

?>

<section>
  <div class="activity-card">
    <div class="row">
      <h4>laporan</h4>
      <div class="form-inline d-flex">
        <input type="text" class="form-control form-control-sm">
        <button class="btn btn-sm btn-info ml-1">cari</button>
      </div>
    </div>
    <div class="row">
      <div class="table-responsive table-sm">
        <table class="table table-hover">
          <thead>
            <tr>
              <th>no.</th>
              <th>Nama</th>
              <th>NIB</th>
              <th>cabang</th>
              <th>Jabatan</th>
              <th>kode Jabatan</th>
              <th>Jumlah masuk</th>
              <th>Gaji</th>
              <th>Uang Makan</th>
              <th>potongan</th>
              <th>sisa kasbon</th>
              <th>gaji akhir</th>
              <th>œ</th>
            </tr>
          </thead>
          <tbody>
            <?php
            $no = 1;
            $date = date('y-d-m');
            $sql = mysqli_query($conn, "SELECT * FROM `gaji_laporans` WHERE `kets` = '0' OR `tgl` ='$date'");
            while ($spctk = mysqli_fetch_array($sql)) {

            ?>
              <tr>
                <td><?= $no++; ?>.</td>
                <td><?= $spctk['nama']; ?></td>
                <td><?= $spctk['nib']; ?></td>
                <td><?= $spctk['cabang']; ?></td>
                <td><?= $spctk['jabatan']; ?></td>
                <td>00<?= $spctk['ko_jbtn']; ?></td>
                <td><?= $spctk['t_masuk']; ?></td>
                <td><?= rupiah($spctk['gaji']); ?></td>
                <td><?= rupiah($spctk['um']); ?></td>
                <td><?= rupiah($spctk['potongan']); ?></td>
                <td><?= rupiah($spctk['siskasb']); ?></td>
                <td><?= rupiah($spctk['gaji_fin']); ?></td>
                <td> </td>
              </tr>
            <?php
            }
            ?>
          </tbody>
        </table>
      </div>
    </div>
  </div>
</section>
<?php
$intrs = 5;
$getdate = date_create(date('y-m-d'));
date_add($getdate, date_interval_create_from_date_string($intrs . 'year'));
$todate = date_format($getdate, 'y-m');
echo date('y-m') . '&emsp;' . $todate;

include "footer.php";
?>