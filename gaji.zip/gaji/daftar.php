<?php
include "header.php";
$gaji_awal = mysqli_query($conn, "SELECT * FROM `gaji_gaji_golongan` WHERE `id` = '2'");
$ga = mysqli_fetch_assoc($gaji_awal);
$um_awal = mysqli_query($conn, "SELECT * FROM `gaji_um_golongan` WHERE `id` = '1'");
$u = mysqli_fetch_assoc($um_awal);
// $tabel = mysqli_query($conn, "SELECT * FROM `gaji_daftar`") or die(mysqli_error($conn));
// $cekis = mysqli_fetch_assoc($tabel);
// $date = date('Y-m-d');
// if ($date = $cekis['est_naik']) {
//   //settt
//   $jabplus = $cekis['masa_kerja'];
//   $dateup = date_create($cekis['est_naik']);
//   date_add($dateup, date_interval_create_from_date_string('1year'));
//   $setup = date_format($dateup, 'Y-m-d');
//   //update_database
//   // mysqli_query($conn, "UPDATE `gaji_daftar` SET `masa_kerja` + 1, `est_naik`='$setup' WHERE `est_naik`='$date'") or die(mysqli_error($conn));
// } else {
//   echo "errrrrrr";
// }
?>
<section>
  <div class="activity-card">
    <div class="form-inline d-flex">
      <h3>Data Karyawan</h3>
      <button class="btn btn-sm btn-info ml-1 mb-1" data-toggle="modal" data-target="#myModal">tambah</button>
    </div>
    <div class="col">
      <div class="form-inline d-flex">
        <input class="form-control mb-2" type="text" id="myInpt" placeholder="cari">
      </div>
    </div><br>
    <!--tabel  -->
    <div class="col">
      <div class="x-scroll">
        <div class="div1"></div>
      </div>
      <div class="x-scroll2">
        <div class="table-responsive table-sm div2">
          <table class="table table-hover" id="respon">
            <thead class="thead-dark">
              <tr>
                <th>smth</th>
                <th>No.</th>
                <th>Nama</th>
                <th>Alamat </th>
                <th>Pendidikan Terakhir</th>
                <th>NIB</th>
                <th>Cabang</th>
                <th>Jabatan</th>
                <th>kode jabatan</th>
                <th>Masa Kerja</th>
                <th>Gaji</th>
                <th>Uang Makan</th>
                <th>tahun bergabung</th>
                <th>Kas Bon</th>
                <th>status</th>
                <th>keterangan</th>
                <th>aksi</th>
              </tr>
            </thead>
            <tbody id="myTabl">
              <?php
              $no = 1;
              $tabel1 = mysqli_query($conn, "SELECT * FROM `daftar_pegawai` ORDER BY `id` ASC") or die(mysqli_error($conn));
              while ($lup = mysqli_fetch_array($tabel1)) {
                if ($lup['status'] == "tidak") {
                  echo '<tr style="background-color:#FFDADA;">';
                } else if ($lup['status'] == "cuti") {
                  echo '<tr style="background-color:#FFF1B2;">';
                } else {
                  echo '<tr>';
                }
              ?>
                <form action="index.php" method="POST">
                  <!-- ntahlah untuk apa -->
                  <td>
                    <div class="form-control-inline d-flex">
                      <input type="hidden" name="index" value="<?= $lup['nama']; ?>">
                      <button class="btn btn-sm">link</button>
                    </div>
                  </td>
                  <!--

                  -->
                  <td><a href="index.php?index=<?= $lup['nama']; ?>"><?= $no++ ?>.</a></td>
                  <td><a href="edit_pegawai.php?id=<?= $lup['id']; ?>" style="font-weight:bolder; text-decoration:none; color:#4B4B4B;"><?= $lup['nama'] ?></a></td>
                  <td style="font-size: 1em;">Lorem Ipsum is simply dummy text of the printing and typesetting industry. the 1500s,</td>
                  <td><?= $lup['pddk'] ?></td>
                  <td><?= $lup['nib'] ?></td>
                  <td><?= $lup['cbg'] ?></td>
                  <td><?= $lup['jbtn'] ?></td>
                  <td>00<?= $lup['ko_jbtn'] ?></td>
                  <td><?= $lup['ms_krj'] ?> thn</td>
                  <td><?= rupiah($lup['gaji']) ?></td>
                  <td><?= rupiah($lup['um']) ?></td>
                  <td><?= $lup['th_gb'] ?></td>
                  <td><?= rupiah($lup['kas_bon']) ?></td>
                  <td><?= $lup['status'] ?></td>
                  <?php
                  if (empty($lup['keterangan'])) {
                    $ket = '-';
                  } else {
                    $ket =  $lup['keterangan'];
                  }

                  ?>
                  <td><?= $ket ?></td>
                  <td>
                    <a href="edit_pegawai.php?id=<?= $lup['id']; ?>" class="btn btn-sm aksi" style="background-color:#9DCBB8 ;"><span class="ti-settings"></span></a>
                  </td>
                </form>
                </tr>
              <?php
              }
              ?>
            </tbody>
          </table>
        </div>
      </div>
    </div>
  </div>


  <div class="modal fade" id="myModal">
    <div class="modal-dialog modal-dialog-centered modal-lg">
      <div class="modal-content">

        <!-- Modal Header -->
        <div class="modal-header">
          <h4 class="modal-title">Tambah Pegawai</h4>
          <button type="button" class="close" data-dismiss="modal">&times;</button>
        </div>

        <!-- Modal body -->
        <div class="modal-body">
          <form action="" method="POST">
            <div class="form-row">
              <div class="col">
                <label for="nama"> Nama : </label>
                <input type="text" id="nama" name="nama" class="form-control" required>
              </div>
              <div class="col">
                <label for="degre"> Pendidikan Terakhir : </label>
                <input type="text" id="degre" name="pddk" class="form-control" required>
              </div>
              <div class="col">
                <label for="join"> Tanggal Masuk : </label>
                <input type="date" id="join" name="tgl" class="form-control" required>
              </div>
            </div>
            <div class="form-row">
              <div class="col">
                <label for="NIB"> NIB : </label>
                <input type="text" id="NIB" name="nib" class="form-control" required>
              </div>
            </div>
            <div class="form-row">
              <div class="col">
                <label for="alamat"> Alamat : </label>
                <textarea type="text" id="alamat" name="almt" class="form-control" required></textarea>
              </div>
            </div>
            <div class="form-row">
              <div class="col">
                <label for="cabang"> Cabang : </label>
                <input type="text" id="cabang" name="cbg" class="form-control" required>
              </div>
              <div class="col">
                <?php
                $ceks = mysqli_query($conn, "SELECT * FROM `gaji_jabatan` ORDER BY `id`");
                ?>
                <label for="jabatan"> Jabatan : </label>
                <select class="form-control" name="jbtn" id="jabatan" required>
                  <option value="" selected disabled>pilih jabatan</option>
                  <?php
                  while ($jab = mysqli_fetch_array($ceks)) {
                  ?>
                    <option value="<?= $jab['jabatan']; ?>"><?= $jab['jabatan'] . '||' . $jab['kode']; ?></option>
                  <?php
                  }
                  ?>
                </select>
              </div>
              <div class="col">
                <?php
                $kod = mysqli_query($conn, "SELECT * FROM `gaji_gaji_golongan` WHERE `tonase` = '' ORDER BY `golongan`");
                ?>
                <label for="kode"> kode Jabatan: </label>
                <select class="form-control" name="kodej" id="kode" required>
                  <option value="" selected disabled>pilih kode</option>
                  <?php
                  while ($f = mysqli_fetch_array($kod)) {

                    echo '<option value="' . $f['golongan'] . '">' . $f['golongan'] . '</option>';
                  }
                  ?>
                </select>
              </div>
            </div>
        </div>

        <!-- Modal footer -->
        <div class="modal-footer">
          <button type="submit" id="acc" name="tambah_karyawan" class="btn btn-primary btn-sm">simpan</button>
          <?php
          if (isset($_POST['tambah_karyawan'])) {
            $name = $_POST['nama'];
            $pddk = $_POST['pddk'];
            $join = $_POST['tgl'];
            $nib = $_POST['nib'];
            $almt = $_POST['almt'];
            $cbg = $_POST['cbg'];
            $jabatan = $_POST['jbtn'];
            $kode_jabatan = $_POST['kodej'];

            //estimasi kenaikan
            $date = date_create(date('Y-m-d'));
            date_add($date, date_interval_create_from_date_string('1 year'));
            $date2 = date_create(date('Y-m-d'));
            date_add($date2, date_interval_create_from_date_string('4 year'));
            $est_naik = date_format($date, 'Y-m-d');
            $est_naik_um = date_format($date2, 'Y-m-d');

            //gaji um awal
            $hitgaj = mysqli_query($conn, "SELECT * FROM `gaji_gaji_golongan` WHERE `golongan` = '$kode_jabatan'");
            $gaji = mysqli_fetch_assoc($hitgaj);
            $hitum = mysqli_query($conn, "SELECT * FROM `gaji_um_golongan` WHERE `golongan` = '$kode_jabatan'");
            $um = mysqli_fetch_assoc($hitum);
            $gaji_awal = $ga['tonase'] + $gaji['tunjangan'];
            $um_awal = $u['tonase'] + $um['tunjangan'];

            mysqli_query($conn, "INSERT INTO `daftar_pegawai` (nama,alamat,pddk,nib,cbg,jbtn,ko_jbtn,ms_krj,gaji,um,th_gb,est_naikgaji,est_naikum,status) VALUE('$name','$almt','$pddk','$nib','$cbg','$jabatan','$kode_jabatan','0','$gaji_awal','$um_awal','$join','$est_naik','$est_naik_um','aktif')") or die(mysqli_error($conn));
            echo '<script>window.location.href="daftar.php?akoens=yups";</script>';
          }
          ?>
          </form>
          <button type="button" class="btn btn-warning btn-sm" data-dismiss="modal">Batal</button>
        </div>
      </div>

    </div>
  </div>

  <script>
    $(document).ready(function() {
      $("#myInpt").on("keyup", function() {
        var value = $(this).val().toLowerCase();
        $("#myTabl tr").filter(function() {
          $(this).toggle($(this).text().toLowerCase().indexOf(value) > -1)
        });
      });
      $("#myInpt").focus();
    });
    $(function() {
      $(".x-scroll").scroll(function() {
        $(".x-scroll2").scrollLeft($(".x-scroll").scrollLeft());
      });
      $(".x-scroll2").scroll(function() {
        $(".x-scroll").scrollLeft($(".x-scroll2").scrollLeft());
      });
    });
  </script>
</section>

<?php
include "footer.php";

?>