<?php
include "header.php";
?>
<div class="dash-cards">
  <a href="daftar.php" style="text-decoration: none;">
    <div class="card-single bg-info">
      <div class="card-body">
        <span class="ti-user"></span>
        <div>
          <?php
          $karyawan = mysqli_query($conn, "SELECT COUNT(nama) AS 'total' FROM `daftar_pegawai`");
          $jumlah_k = mysqli_fetch_assoc($karyawan);
          ?>
          <h3>Karyawan</h3>
          <h4><?= $jumlah_k['total']; ?> pegawai</h4>
        </div>
      </div>
    </div>
  </a>
  <div class="card-single bg-warning ">
    <div class="card-body">
      <span class="ti-envelope"></span>
      <div>
        <h3>laporan</h3>
        <h4> 45 <span class="ti-envelope" style="font-size: 1rem;"></span></h4>
      </div>
    </div>
  </div>
  <div class="card-single bg-secondary">
    <div class="card-body">
      <span class="ti-search"></span>
      <div>
        <h3>secondary</h3>
        <h4>???</h4>
      </div>
    </div>
  </div>
  <div class="card-single bg-secondary">
    <div class="card-body">
      <span class="ti-search"></span>
      <div>
        <h3>secondary</h3>
        <h4>???</h4>
      </div>
    </div>
  </div>
</div>
<section>
  <div class="activity-card">
    <div class="row">
      <div class="form-inline d-flex">
        <h2>?? :</h2>
        <form action="" method="POST">
          <input type="text" class="form-control form-control-sm ml-2" name="index" id="index" placeholder="masukan NIB / nama" required>
          <button class="btn btn-info btn-sm ml-2" type="submit">Cari</button>
        </form>
      </div>
    </div>
    <?php
    if (isset($_POST['index'])) {
      $nomb = $_POST['index']; //is_numeric();
      $data = mysqli_query($conn, "SELECT * FROM `daftar_pegawai` WHERE `nib` ='$nomb' OR `nama` LIKE '%$nomb%'");
      $jmlh = mysqli_query($conn, "SELECT COUNT(`nama`) AS 'jumlah' FROM `daftar_pegawai` WHERE `nib` = '$nomb' OR `nama` LIKE '%$nomb%'");
      $jumlah = mysqli_fetch_assoc($jmlh);
    ?>
      <div class="from-inline">
        <h4>jumlah data "<?= $jumlah['jumlah']; ?>"</h4>
      </div>
      <?php
      while ($get = mysqli_fetch_array($data)) {
      ?>
        <form id="sess" action="tex.php" method="POST">
          <div class="row border d-flex">
            <!-- data form -->
            <div class="col-md-7">
              <label for="data">
                <h5>Data Karyawan</h5>
              </label>
              <div class="row" id="data">
                <div class="col">
                  <div class="form-row">
                    <label for="nama"><strong>Nama :&nbsp;</strong></label>
                    <!-- kebth-->
                    <input type="hidden" name="id" value="<?= $get['id']; ?>">
                    <input type="hidden" name="nama" value="<?= $get['nama']; ?>">
                    <input type="hidden" name="nib" value="<?= $get['nib']; ?>">
                    <input type="hidden" name="cabang" value="<?= $get['cbg']; ?>">
                    <input type="hidden" name="jabatan" value="<?= $get['jbtn']; ?>">
                    <input type="hidden" name="ko_jbtn" value="<?= $get['ko_jbtn']; ?>">
                    <!----------------------------------->
                    <p id="nama"> <?= $get['nama'] ?></p>
                  </div>
                  <div class="form-row">
                    <label for="nib"><strong>NIB :&nbsp;</strong></label>
                    <p id="nib"><?= $get['nib'] ?></p>
                  </div>
                  <div class="form-row">
                    <label for="pddk"><strong>Pendidikan :&nbsp;</strong></label>
                    <p id="pddk"><?= $get['pddk'] ?></p>
                  </div>
                </div>
                <div class="col">
                  <div class="form-row">
                    <label for="kode"><strong>Kode Jbtn:&nbsp;</strong></label>
                    <p id="pddk"><?= '00' . $get['ko_jbtn'] ?></p>
                  </div>
                  <div class="form-row">
                    <label for="jbt"><strong>Jabatan :&nbsp;</strong></label>
                    <p id="jbt"><?= $get['jbtn'] ?></p>
                  </div>
                  <div class="form-row">
                    <label for="Cabang"><strong>Cabang :&nbsp;</strong></label>
                    <p id="cabang"><?= $get['cbg'] ?></p>
                  </div>
                </div>
                <div class="col">
                  <div class="form-row">
                    <label for="kasbon"><strong>Kasbon:&nbsp;</strong></label>
                    <p id="kasbon"><?= rupiah($get['kas_bon']) ?></p>
                  </div>
                </div>
              </div>
            </div>
            <!--input form -->
            <div class="col-md-5">
              <label for="potong">
                <h5>Potongan | jumlah masuk</h5>
              </label>
              <div class="row" id="potong">
                <div class="col">
                  <div class="form-group">
                    <label for="bpjs"><strong>pot.BPJS :&nbsp;</strong></label>
                    <input type="number" id="bpjs" name="bpjs" class="form-control form-control-sm fms" required>
                    <label for="bon"><strong>pot.kas bon :&nbsp;</strong></label>
                    <input type="number" id="bon" name="bon" class="form-control form-control-sm fms" required>
                  </div>
                </div>
                <div class="col">
                  <div class="form-group">
                    <label for="dln"><strong>pot.lain-lain :&nbsp;</strong></label>
                    <input type="number" id="dln" name="pln" class="form-control form-control-sm fms" required>
                    <label for="jblhmsk"><strong>jumlah Masuk :&nbsp;</strong></label>
                    <input type="number" id="jblhmsk" name="j_msk" class="form-control form-control-sm fms" required>
                  </div>
                  <div class="form-group d-flex">
                    <input type="hidden" name="gaji" value="<?= $gaji; ?>">
                    <input type="hidden" name="um" value="<?= $um; ?>">
                    <!-- <a href="#" class="btn btn-primary btn-sm">Cetak</a> -->
                    <button type="submit" class="btn btn-success btn-sm ml-1" id="simps">Simpan</button>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </form>
    <?php
      }

      if ($jumlah['jumlah'] == 0) {
        echo '<div class="row"><div class="col"><p style="color:#C42D00; font-weight:bold">Data tidak di temukan... !! </p></div></div>';
      }
    }
    if (!isset($_POST['index'])) {
      echo '<div class="row"><p style="font-weight:bold">isi dulu boss..!!</p></div>';
    }
    ?>
  </div>
</section>
<script>
  $(document).ready(function() {
    $("#index").focus();
  });
</script>
<?php
include "footer.php";
?>