<?php
include "header.php";
//take awal gaji um
$gaji_awal = mysqli_query($conn, "SELECT * FROM `gaji_gaji_golongan` WHERE `id` = '2'");
$ga = mysqli_fetch_assoc($gaji_awal);
$um_awal = mysqli_query($conn, "SELECT * FROM `gaji_um_golongan` WHERE `id` = '1'");
$u = mysqli_fetch_assoc($um_awal);

?>

<section>
  <div class="card">
    <h4>Tambah data Karyawan</h4>
  </div>
  <div class="activity-card">
    <form action="" method="POST">
      <div class="row">
        <div class="col">
          <div class="form-group">
            <label for="nama">Nama :</label>
            <input type="text" id="nama" name="nama" class="form-control" required>
          </div>
          <div class="form-group">
            <label for="almt">Alamat :</label>
            <textarea id="almt" name="almt" class="form-control" required></textarea>
          </div>
          <div class="form-row">
            <div class="col">
              <label for="nib">NIB :</label>
              <input id="almt" name="nib" class="form-control" required>
            </div>
            <div class="col">
              <label for="pddk">Pendidikan :</label>
              <input type="text" id="pddk" name="pddk" class="form-control" required>
            </div>
          </div>
        </div>
        <div class="col">
          <div class="form-group">
            <label for="tgl">tanggal Masuk :</label>
            <input type="date" id="tgl" name="join" class="form-control" required>
          </div>
          <div class="form-group">
            <label for="cab">Cabang :</label>
            <input type="text" id="cab" name="cab" class="form-control" required>
          </div>
          <?php
          $ceks = mysqli_query($conn, "SELECT * FROM `gaji_jabatan` ORDER BY `id`");
          ?>
          <div class="form-row">
            <div class="col">
              <label for="jbt">Jabatan :</label>
              <select name="jbt" id="jbt" class="form-control" required>
                <option value="" selected disabled>pilih jabatan</option>
                <?php while ($jbtn = mysqli_fetch_array($ceks)) {
                ?>
                  <option value="<?= $jbtn['jabatan']; ?>"><?= $jbtn['jabatan']; ?></option>
                <?php
                }
                ?>
              </select>
            </div>
            <div class="col">
              <label for="kdt">kode jabatan :</label>
              <select class="form-control" name="kode" id="kdt" required>
                <option value="" selected disabled>pilih kode</option>
                <?php
                $kod = mysqli_query($conn, "SELECT * FROM `gaji_gaji_golongan` WHERE `tonase` = '' ORDER BY `golongan`");
                while ($koe = mysqli_fetch_array($kod)) { ?>
                  <option value="<?= $koe['golongan']; ?>"><?= $koe['golongan']; ?></option>
                <?php
                } ?>
              </select>
            </div>
          </div>
          <div class="form-group">
          </div>
          <div class="form-group">
            <a href="index.php" class="btn btn-warning">batal</a>
            <button class="btn btn-primary" name="simpan_karyawan">simpan</button>
          </div>
        </div>
      </div>
    </form>
    <?php
    if (isset($_POST['simpan_karyawan'])) {
      $nama = $_POST['nama'];
      $almt = $_POST['almt'];
      $pddk = $_POST['pddk'];
      $nib = $_POST['nib'];
      $join = $_POST['join'];
      $cab = $_POST['cab'];
      $jbt = $_POST['jbt'];
      $kode = $_POST['kode'];

      //estimasi kenaikan
      $date = date_create(date('Y-m-d'));
      date_add($date, date_interval_create_from_date_string('1 year'));
      $date2 = date_create(date('Y-m-d'));
      date_add($date2, date_interval_create_from_date_string('4 year'));
      $est_naik = date_format($date, 'Y-m-d');
      $est_naik_um = date_format($date2, 'Y-m-d');

      //gaji um awal
      $hitgaj = mysqli_query($conn, "SELECT * FROM `gaji_gaji_golongan` WHERE `golongan` = '$kode'");
      $gaji = mysqli_fetch_assoc($hitgaj);
      $hitum = mysqli_query($conn, "SELECT * FROM `gaji_um_golongan` WHERE `golongan` = '$kode'");
      $um = mysqli_fetch_assoc($hitum);
      $gaji_awal = $ga['tonase'] + $gaji['tunjangan'];
      $um_awal = $u['tonase'] + $um['tunjangan'];
      //echo $kode . " " . rupiah($um_awal) . " " . rupiah($gaji_awal);

      mysqli_query($conn, "INSERT INTO `daftar_pegawai` (nama,alamat,pddk,nib,cbg,jbtn,ko_jbtn,ms_krj,gaji,um,th_gb,est_naikgaji,est_naikum,status) VALUE('$nama','$almt','$pddk','$nib','$cab','$jbt','$kode','0','$gaji_awal','$um_awal','$join','$est_naik','$est_naik_um','aktif')");
      header('location: tambah.php');
    }

    ?>
  </div>
</section>
<?php
include "footer.php";
?>