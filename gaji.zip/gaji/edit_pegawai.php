<?php
include "header.php";
if (isset($_GET['id'])) {
  $rbh = mysqli_query($conn, "SELECT * FROM `daftar_pegawai` WHERE `id` = '$_GET[id]'");
  while ($a = mysqli_fetch_array($rbh)) {
    $stt = $a['status'];
?>
    <section>
      <div class="row">
        <div class="form-inline d-flex">
          <h4>edit data</h4>
          <a href="daftar.php" class="btn btn-info btn-sm ml-4 mb-1">Kembali </a>
        </div>
      </div>
      <div class="card" style="margin-top: 12px;">
        <form action="akse.php" method="POST">
          <div class="row">
            <div class="col">
              <div class="form-group">
                <div class="col">
                  <input type="hidden" name="id" value="<?= $a['id']; ?>">
                  <label for="nama">Nama :</label>
                  <input id="nama" name="nama" class="form-control form-control-sm" type="text" value="<?= $a['nama']; ?>">
                </div>
                <div class="col">
                  <label for="nib"> NIB :</label>
                  <input id="nib" name="nib" class="form-control form-control-sm" type="text" value="<?= $a['nib']; ?>" readonly>
                </div>
                <div class="col">
                  <label for="pdk">Pendidikan :</label>
                  <input id="pdk" name="pendi" class="form-control form-control-sm" type="text" value="<?= $a['pddk']; ?>">
                </div>
                <div class="col">
                  <label for="alamat">Alamat :</label>
                  <textarea id="alamat" name="almt" class="form-control form-control-sm" type="text"><?= $a['alamat']; ?></textarea>
                </div>
              </div>
            </div>
            <div class="col">
              <div class="form-group">
                <div class="row">
                  <div class="col">
                    <label for="cbg">Cabang :</label>
                    <input id="cbg" name="cab" class="form-control form-control-sm" type="text" value="<?= $a['cbg']; ?>">
                  </div>
                  <div class="col">
                    <label for="est1">estimasi gaji:</label>
                    <input id="est1" name="esti" class="form-control form-control-sm" type="date" value="<?= $a['est_naikgaji']; ?>">
                  </div>
                  <div class="col">
                    <label for="est2">estimasi um:</label>
                    <input id="est2" name="estu" class="form-control form-control-sm" type="date" value="<?= $a['est_naikum']; ?>">
                  </div>
                </div>
                <div class="row">
                  <div class="col">
                    <label for="jbt">Jabatan : </label>
                    <input id="jbt" name="jab" type="text" class="form-control form-control-sm" value="<?= $a['jbtn']; ?>">
                  </div>
                  <div class="col">
                    <label for="ko">Kode jbtn : </label>
                    <input id="ko" name="kodjab" type="text" class="form-control form-control-sm" value="00<?= $a['ko_jbtn']; ?>">
                  </div>
                  <div class="col">
                    <label for="stat">Status : </label>
                    <?php
                    if ($stt == 'aktif') {
                      echo '<select name="stat" id="stat" class="form-control form-control-sm" style="background-color: #D9FFB8;">';
                    } elseif ($stt == 'tidak') {
                      echo '<select name="stat" id="stat" class="form-control form-control-sm" style="background-color: #FEAF8F;">';
                    } else {
                      echo '<select name="stat" id="stat" class="form-control form-control-sm" style="background-color:#FFD5AE ;">';
                    }
                    ?>
                    <option value="<?= $a['status']; ?>" selected><?= $a['status']; ?></option>
                    <option value="aktif">Aktif</option>
                    <option value="tidak">Tidak</option>
                    <option value="cuti">Cuti</option>
                    </select>
                  </div>
                </div>
                <div class="col alsn" style="display: none;">
                  <label for="alsn">Alasan:</label>
                  <textarea class="form-control" name="alsn" id="alsn" cols="30" required><?= $a['keterangan']; ?></textarea>
                </div>
                <div class="row">
                  <div class="form-inline d-flex">
                    <a href="daftar.php" id="batal" class="btn btn-secondary btn-sm ml-4">batal</a>
                    <button type="submit" name="simpa" id="simpan" class="btn btn-success btn-sm ml-2">simpan</button>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </form>
      </div>
    </section>

<?php
  }
}

include "footer.php";
?>