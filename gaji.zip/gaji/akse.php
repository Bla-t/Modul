<?php
include "../config.php";
session_start();
if (empty($_SESSION['username']) && empty($_SESSION['pass'])) {
  session_destroy();
  header('location:../index.php?pesan=kick');
} elseif ($_SESSION['type'] == "stok" || $_SESSION['type'] == "leasing") {
  session_destroy();
  header('location:..index.php?pesan=kick');
}

///mulai edit
if (isset($_POST['simpa'])) {
  $nama = $_POST['nama'];
  $pendid = $_POST['pendi'];
  $almt = $_POST['almt'];
  $cabang = $_POST['cab'];
  $jbtn = $_POST['jab'];
  $kod_jbtn = $_POST['kodjab'];
  $stat = $_POST['stat'];
  if ($stat == 'aktif') {
    $alasan = '';
  } else {
    $alasan = $_POST['alsn'];
  }
  mysqli_query($conn, "UPDATE `daftar_pegawai` SET `nama`= '$nama',`alamat` = '$almt',`pddk`='$pendid',`cbg`='$cabang',`jbtn` = '$jbtn', `ko_jbtn` = '$kod_jbtn',`keterangan`='$alasan',`status` ='$stat' WHERE `id` = '$_POST[id]' ");
  header("location:daftar.php?yes=$nama+$jbtn");
}
