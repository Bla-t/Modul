<style type="text/css">
	/*a{
		color: yellow;
	}*/
	td{
		color: #00F5ED;
	}
	.target{

	}
</style>

<?php
date_default_timezone_set('Asia/Jakarta');
	//$dat= date('Y-m-d');
	$no=1;
	$query = mysqli_query($conn, "SELECT * FROM `dat_leasing` WHERE  `jenis_leasing`='TANAH' ORDER BY `thn_pengada` ASC") or die(mysqli_error($conn));
	while($fetch = mysqli_fetch_array($query)){
		?>
		<tr>
		    <form method="POST" action="updell.php">
			<td style="color: white;"><?php echo $no++?></td>
			<input type="hidden" value="<?php echo $fetch['product_id']?>" name="aisd">
			    <input type="hidden" name="id" value="<?php echo $fetch['No_Pol']?>">
			<td><input type="hidden" value="<?php $fetch['product_id']?>"><a name="id" class="text-warning text-decoration-none target" href="edit_sup.php?id=<?php echo $fetch['No_Pol'];?>" target=""><?php echo $fetch['No_Pol']?></a>
			</td>
			<td><?php echo $fetch['atas_nama']?></td>
			<td><input class="form-control" name="ket" value="<?php echo $fetch['Keterangan']?>" onkeyup="this.value = this.value.toUpperCase()"></td>
			<td>
			    <button class="btn btn-warning" name="smp" id="simps">Simpan</button>
			</td>
			<td>
    			<button class="btn btn-danger" name="delt" id="del">Hapus</button>
			</td>
			</form>
		</tr>

<?php
}
?>