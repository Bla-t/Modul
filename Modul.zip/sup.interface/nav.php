<?php
  include '../config.php';
    ?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8" name="viewport" content="width=device-width, initial-scale=1">
      <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
      <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
      <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
      <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
      <script type="text/javascript" src="https://code.jquery.com/jquery-3.3.1.min.js"></script> 
      <?php
      if($_SESSION['levl'] == "admin" ||$_SESSION['levl'] == "operator" ||$_SESSION['levl'] == "sudo"){
    		echo('<link rel="stylesheet" href="../css/body.css">');
        	}
      else if($_SESSION["levl"] == "visitor"){
          echo ('<link rel="stylesheet" href="../css/body-pengunjung.css">');
      }
    ?>
<style type="text/css">
  .font-italic {
      
      font-size: 15px;
      background-color:#950000;
      border-radius: 5%;
  }
  
  body{
  		background: url('../backgrond/bek2.jpg')fixed; 		
  	}
 
</style>
<?php
    
    $iti = $_SESSION['ID'];
    $kue = mysqli_query($conn, "SELECT * FROM `dat_uss` WHERE `id`='$iti'") or die(mysqli_error($conn));
    while($pet = mysqli_fetch_array($kue)){
              ?>
  <nav class="navbar navbar-expand-md bg-dark navbar-dark fixed-top">
  <a class="navbar-brand" href="../home.php">Home</a>
  <button class="navbar-toggler navbar-toggler-right" type="button" data-toggle="collapse" data-target="#collapsibleNavbar">
    <span class="navbar-toggler-icon"></span>
  </button>
  <div class="collapse navbar-collapse" id="collapsibleNavbar">
    <ul class="navbar-nav mr-auto">
      <li class="nav-item">
        <a class="nav-link" href="index.php">Data Leasing</a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="akuns.php"> Akoen</a>
      </li>
      <li class="nav-item">
          <a class="nav-link" href="carih.php">Tracking</a>
      </li>
    </ul>
    <ul class="navbar-nav"> 
      <li class="nav-item dropdown">
      <a class="nav-link dropdown-toggle font-weight-bold font-italic" href="" id="navbardrop" data-toggle="dropdown">
        <?php echo $pet['nama'];?>
      </a>
      <div class="dropdown-menu bg-secondary">
        <a class="dropdown-item" href="profile.php">Profil</a>
        <a class="dropdown-item" href="../ot.php">logout</a>
      </div>
    </li>
    </ul>
  </div>  
</nav>
<br/>
<?php

     }

  function tgl($tanggal){
    $bulan = array (
      1 =>   
      'Jan',
      'Feb',
      'Mar',
      'Apr',
      'Mei',
      'Juni',
      'Juli',
      'Agus',
      'Sept',
      'Okt',
      'Nov',
      'Des'
    );
    $pecahkan = explode('-', $tanggal);
    
    // variabel pecahkan 0 = tanggal
    // variabel pecahkan 1 = bulan
    // variabel pecahkan 2 = tahun
   
    return $bulan[ (int)$pecahkan[1] ] . ', ' . $pecahkan[0];
  }
  

?>
</head>
<body>

</body>
</html>
