<?php
session_start();
if(empty($_SESSION['username']) && empty($_SESSION['pass'])){
		header("location:index.php?pesan=gagal");
	}
?>
<!DOCTYPE html>
<html>
<head>
	<title>Profil</title>
	<?php
		include 'nav.php';
	 ?>
    	 <style type="text/css">
    	 <?php
    	 	if($_SESSION['levl'] == "admin" ||$_SESSION['levl'] == "sudo"){
                ?>		
    	 	.adminsd{display: block;}
	 	<?php
    	 	}
	 	else {
	 	    ?>
 	    
    	 	.adminsd{display: none;}
    	 	
    	 	<?php
	 	}
	 	?>
	 </style>
</head>
<body>
	<div class="container-fluid">
	    <br/>
		<div class="row">
			<div class="col-md-6">
				<?php
					if (isset($_GET['masuk'])) {
						if ($_GET['masuk'] == "masuk"){
						    echo("Profil berhasil di rubah. . . !");
    					}
    					else if ($_GET['masuk'] == "tambah"){
    					    echo("User Baru Berhasil di tambahkan. . . !");
    					}
					}
					
					$iti = $_SESSION['ID'];
					$kue = mysqli_query($conn, "SELECT * FROM `dat_uss` WHERE `id`='$iti'") or die(mysqli_error($conn));
					while($pet = mysqli_fetch_array($kue)){							

				?>
				<div class="card">
					<h3 class="display-4">-Profil "<?php echo $pet['nama']?>"</h3>
					<div class="card-body bg-secondary">
						<form name="frmchange" method="POST" action="" onSubmit="return validatepass()">							
						<div class="form-group">						
							<label>Nama</label>
							<input class="form-control" type="text" name="nam" value="<?php echo $pet['nama']?>">
							<label>Tipe Akun</label>
							<input type="hidden" name="ids" value="<?php echo $pet['id']?>">
							<input class="form-control" type="text" name="aq" value="<?php echo $pet['levl']?>" readonly>
							<label>User Name</label>
							<input class="form-control" type="text" name="Unam" value="<?php echo $pet['username']?>">
						</div>
						<div class="form-row">
							<div class="col">
								<label>Password</label>
								<input type="Password" name="pass" id="pass" class="form-control" value="<?php echo $pet['password']?>" required> 
							</div>
							<div class="col">
								<label>Ulangi Password</label>
								<input type="Password" name="word" id="word" class="form-control" required>
							</div>
						</div><br>		
						<div class="form-gorup">
							<a class="btn btn-warning" href="index.php">Kembali</a>
							<button type="submit" class="btn btn-danger" id="sup" name="simps">Simpan</button>
						</div>
						<?php
							}

							if (isset($_POST['simps'])) {
								$nam = $_POST['nam'];
								$uss = $_POST['Unam'];
								$pasd = $_POST['word'];
								$ds = $_POST['ids'];

								mysqli_query($conn,"UPDATE `dat_uss` SET `nama`= '$nam',`username`='$uss',`password`='$pasd' WHERE `id` ='$ds'")or die(mysqli_error($conn));
								header("location:profile.php?masuk=masuk");
							}

						?>
						</form>
					</div>
				</div>
			<br/><br/></div>
			 <div class="col-md-6 adminsd">
				<div class="card">
					<h3 class="display-4 font-weight-normal"> -Tambah Akun</h3>
					<div class="card-body bg-dark">
						<form method="POST" action="">
						<div class="form-group">						
							<label>Nama</label>
							<input class="form-control" type="text" name="namplus" value="">
							<label>Tipe Akun</label>
							<select class="form-control" name="aqplus" required>
							<option value="admin"> Admin</option>
							<option value="operator"> Operator</option>
							<option value="visitor"> Pengawas</option>
							<option value="sudo" id="sud" style="<?php if($_SESSION['levl'] == "sudo"){echo("display:block");}else{ echo("display:none");}?>"> Superuser</option>
							</select>
							<label>User Name</label>
							<input class="form-control" type="text" name="Unamplus" value="">
						</div>
						<div class="form-row">
							<div class="col">
								<label>Password</label>
								<input type="Password" name="passplus" id="pp" class="form-control" value="" required> 
							</div>
							<div class="col">
								<label>Ulangi Password</label>
								<input type="Password" name="wordplus" id="wp" class="form-control" required>
							</div>
						</div><br>		
						<div class="form-gorup">
							<button class="btn btn-danger" id="tmpb" name="simpes">Simpan</button>
						</div>
						<?php
                            if (isset($_POST['simpes'])) {
								$nam = $_POST['namplus'];
								$uss = $_POST['aqplus'];
								$pasd = $_POST['Unamplus'];	
								$ds = $_POST['wordplus'];		

								mysqli_query($conn,"INSERT INTO `dat_uss` (nama,username,password,levl) VALUE ('$nam','$pasd','$ds','$uss')")or die(mysqli_error($conn));
								header("location:profile.php?masuk=tambah");
							}
						?>
						</form>
					</div>
				</div>
			</div>
		</div>
	</div>
	<script type="text/javascript">
		   $(function () {
            $("#sup").click(function () {
                var password = $("#pass").val();
                var confirmPassword = $("#word").val();
                if (password != confirmPassword) {
                    alert("Password / Kata Sandi tidak sama");
                    return false;
                }
                return true;
            });
            $("#tmpb").click(function () {
                var password = $("#pp").val();
                var confirmPassword = $("#wp").val();
                if (password != confirmPassword) {
                    alert("Password / Kata Sandi tidak sama");
                    return false;
                }
                return true;
            });
        });

	</script>
<!-- <h1 class="display-2 bg-danger"><?php echo $_SESSION['nama']?></h1> -->
</body>
</html>