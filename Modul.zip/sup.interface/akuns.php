<?php
session_start();
if(empty($_SESSION['username']) && empty($_SESSION['pass'])){
		header("location:index.php?pesan=gagal");
	}
?>
<!DOCTYPE html>
<html lang="en">
<head>
	<title>Update | Data Leasing</title>
	<?php
		date_default_timezone_set('Asia/Jakarta');
		include 'nav.php';
	?>
</head>
<style type="text/css">
	td{
		color: #00F5ED;
	}
</style>
<body> 
	<?php
		$isi=$_GET['id'];
	?>
	<div class="container-fluid">
	    	<?php
	if (isset($_GET['akoens'])) {
	    
    	 if($_GET['akoens'] == "ups"){
    	        echo('
    	          <div class="alert alert-success alert-dismissible fade show text-center">
    	              <button type="button" class="close" data-dismiss="alert">&times;</button>
    	              Update<strong> Username</strong> okeh. . . ! !
    	          </div>');
    	}
    	else if($_GET['akoens'] == "haps"){
    	    
    	    echo('
    	          <div class="alert alert-warning alert-dismissible fade show text-center">
    	              <button type="button" class="close" data-dismiss="alert">&times;</button>
    	              <strong>Terhapuzz</strong> loohh . . . !!
    	          </div>');
    	}
	}
	?>
	<div class="row">	
	<div class="col-md-6">
		<div class="card bg-dark">
			<div class="card-body">
				<a class="btn btn-secondary" href="updet_leas.php">Tampilkan Semua</a><br /><br />
				<input class="form-control" id="myInput" type="text" placeholder="Cari.." >
			</div>
		</div>
	</div>
	<div class="col-md-6">
		<h5 class="text-right display-4"><kbd class="text-warning"><?php echo tgl(date('Y-m'));?></kbd><br/><kbd class="text-warning jm"><?php echo date('H:i:s');?></kbd></h5>
	</div>
</div>
	<div class="row">
	<div class="col-md-11">
		<label class="font-weight-normal"><h2 class="text-warning">akun-akun</h2></label>
		<div class="scroll">
		<table class="table table-dark table-hover">
			<thead class="thead-dark">
				<tr>
					<th>No.</th>
					<th>Level</th>
					<th>Nama</th>
					<th>Username</th>
					<th>Password</th>
					<th>Hapus</th>
				</tr>
			</thead>
			<tbody id="akoen">
			    <?php
			    $no=1;
			    $akoen = mysqli_query($conn, "SELECT * FROM `dat_uss`") or die(mysqli_error($conn));
			    while ($catch= mysqli_fetch_array($akoen)){
			    ?>
			    <tr>
		        <form method="POST" action="updell.php">
    			    <td><?php echo $no++;?></td>
    			    <td><input type="hidden" name="ides" value="<?php echo $catch['id']?>"><?php echo $catch['levl']?></td>
    			    <td><?php echo $catch['nama']?></td>
    			    <td><?php echo $catch['username']?></td>
    			    <td><input class="form-control" type="text" name="pass" value="<?php echo $catch['password']?>"></td>
    			    <td>
    			        <button class="btn btn-danger" name="haps"> Hapus</button>
    			    </td>
			    </form>
			    </tr>
			    <?php
			    }
			    ?>
			</tbody>
		</table>
		</div>
	</div>
	</div>
	</div>	
	<script src="js/jquery-3.2.1.min.js"></script>
	<script type="text/javascript">
		
	</script>
</body>
<footer>
	<?php
		include 'footer.php';
	?>
</footer>
</html>