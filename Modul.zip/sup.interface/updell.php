<?php
include "../config.php";

        //keterangna leasing//
    $id = $_POST['id'];
    $ids = $_POST['aisd'];
    $kets = $_POST['ket'];
    
    if (isset($_POST['smp'])){
        
        mysqli_query($conn,"UPDATE `dat_leasing` SET `Keterangan`='$kets' WHERE `product_id`='$ids'") or die(mysqli_error($conn));
            
            header("location:index.php?gud=gud");
    }
    if (isset($_POST['delt'])){
        
        mysqli_query($conn,"DELETE FROM `dat_leasing` WHERE `product_id`='$ids'") or die(mysqli_error($conn));
        mysqli_query($conn,"DELETE FROM `dat_tenor` WHERE `No_pol`='$id'") or die(mysqli_error($conn));
    
        header("location:index.php?gud=yet");
    }
    
    //akoens//
    
    $aidi = $_POST['ides'];
    $nem = $_POST['name'];
    $useer = $_POST['uss'];
    $pass = $_POST['pass'];
    
    if(isset($_POST['rub'])){
        
        mysqli_query($conn,"UPDATE `dat_uss` SET `nama`='$nem', `username`='$useer', `password`='$pass' WHERE `id` = '$aidi'") or die(mysqli_error($conn));
        
        header("location:akuns.php?akoens=ups");
    }
    
    if (isset($_POST['haps'])){
        
        mysqli_query($conn, "DELETE FROM `dat_uss` WHERE `id`='$aidi'") or die(mysqli_error($conn));
        
        header("location:akuns.php?akoens=haps");
    }
    
    
    ?>