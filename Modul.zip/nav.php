<?php
	error_reporting(E_ALL ^ (E_NOTICE | E_WARNING));
	include "config.php";
	session_start();
	if(empty($_SESSION['username']) && empty($_SESSION['pass'])){
		header("location:../index.php?pesan=gagal");
	}
	else if ($_SESSION['type'] != "leasing") {
		header("location:../index.php?pesan=gagal");
	}
	date_default_timezone_set('Asia/Jakarta');

	/////tanggal/////
	 function tgl($tanggal){
        $bulan = array (
          1 =>'Jan','Feb','Mar','Apr','Mei','Juni','Juli','Agus','Sept','Okt','Nov','Des');
        $pecahkan = explode('-', $tanggal);
        
        // variabel pecahkan 0 = tanggal
        // variabel pecahkan 1 = bulan
        // variabel pecahkan 2 = tahun
       
        return $bulan[ (int)$pecahkan[1] ] . ', ' . $pecahkan[0];
      }

      ///////rupiah/////
	function rupiah($angka){
	
	$hasil_rupiah = "Rp." . number_format($angka,0,',','.');
	return $hasil_rupiah; 
	}

	/////// LOGIN TIPE ///////////////
	$level = $_SESSION['levl'];
	$username = $_SESSION['nama'];
	$milik = $_SESSION['bagian'];
	$iduser =$_SESSION['ID'];
	if (empty($_SESSION['gamb'])){
		$gam = "icon_none.png";
	}
	else{
		$gam = $_SESSION['gamb'];
	}
 ?>
<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="utf-8">	
	<meta name="viewport" content="width=device-width, initial-scale=1, max-scale=1 ">
	<link rel="icon" type="image/gif" href="../gamb/gam.gif"/>
	<meta name="description" content="PT BST">
	<link rel="stylesheet" href="https://cdn.jsdelivr.net/gh/lykmapipo/themify-icons@0.1.2/css/themify-icons.css">
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
	<link rel="stylesheet" type="text/css" href="style.css">
	 <script>
	 	$(document).ready(function(){
	 		setTimeout(function() {
                location.reload();
            }, 300000);
	 	});
	</script>
</head>
<body>
	<input type="checkbox" id="sidebar-toggle">
	<div class="sidebar">
		<div class="sidebar-header">
			<h3 class="brand">
				<a href="home.php">
					<span class="">Dasbor</span>
				</a>
			</h3> 
			<label for="sidebar-toggle" class="ti-menu-alt"></label>
		</div>
		<div class="sidebar-menu">
			<ul><?php 
			if ($milik == "ARM") {			
			
				echo '<li>
					<a href="data_member.php">
						<span class="ti-truck"></span>
						<span>Plat Nomor</span>
					</a>
				</li>';
			}
			else{}
				?>
				<li>
					<a href="updet_leas.php">
						<span class="ti-package"></span>
						<span>Update Data</span>
					</a>
				</li>
				<li>
					<a href="rekap.php">
						<span class="ti-wallet"></span>
						<span>Rekap</span>
					</a>
				</li>
				<li>
					<a href="carih.php">
						<span class="ti-search"></span>
						<span> Traking</span>
					</a>
				</li>
				<?php
				if ($level == "sudo") {
				 	echo'				 
				<li>
					<a href="#">
						<span class="ti-user"></span>
						<span>Users</span>
					</a>
				</li>';
				}
				?>
				<!--<li><?php 
					/*if ($milik == 'GA'){echo
						'<a href="">
						<span class="ti-import"></span>
						<span>Lap. Distribusi</span>
					</a>';} 
					else if($milik == 'ARM'){ echo
						'<a href="lap_pemakaian.php">
						<span class="ti-import"></span>
						<span>Lap. Pemakaian</span>
					</a>';} */?>
				</li>
				<li>
					<a href="">
						<span class="ti-printer"></span>
						<span>text</span>
					</a>
				</li>-->
			</ul>	
		</div> 
	</div>


<div class="main-content">
	<header>
		<div class="search-wrapper">			
			 <img src="gamb/gam.gif" alt="gif" style="width:48px;height:48px;">
			 <h3><?php echo $level.' : '.'"'.$username.'"'; ?></h3>		
		</div>
		<div class="social-icons"><!--
			<span class="ti-bell"></span>
			<span class="ti-comment"></span>
			<span class="ti-user"></span>-->
			<li class="nav-item dropdown">				
				<a class="nav-link dropdown text-light" data-toggle="dropdown" href=""><img class="gambars" src="gamb_user/<?php echo $gam; ?>" alt="<?php echo $icon_user;?>">&emsp;<?php echo $milik;?></a>
				<div class="dropdown-menu">
					<a class="dropdown-item" href="profil_a.php"><span class="ti-user"> Profil</span></a>
					<a class="dropdown-item" href="ot.php"><span class="ti-power-off"> Keluar</span></a>
				</div>
			</li>
		</div>
	</header>
  <!-----------isi------------>
	<main>