<?php 
include "header.php";
 ?>
<section class="recent">
	<?php 
	$nota = $_GET['id'];
	$num=1;
	$query=mysqli_query($conn, "SELECT * FROM `stok_isibeli` WHERE `nota` = '$nota'") or die(mysqli_error($conn)); 
	?>
	<input type="hidden" id="nota" value="<?php echo $nota; ?>">
	<div class="activity-card">
		<div class="form-inline">			
			<h3>Nota Pembelian : <?php echo $nota; ?> |</h3>
			<a class="btn btn-info btn-sm" href="lap_beli.php" >Kembali</a>
		</div>	
		<div class="table-responsive" id="tabp">
			<table>
				<thead>
					<tr>
						<th>No.</th>
						<th>SKU</th>
						<th>Nama</th>
						<th>jumlah</th>
						<th>Total</th>				
					</tr>
				</thead>
				<tbody>
					<?php while($rinci=mysqli_fetch_array($query)){ ?>
					<tr>
						<td><?php echo $num++; ?></td>
						<td><?php echo $rinci['kode_barang']; ?></td>
						<td><?php echo $rinci['nama']; ?></td>
						<td><?php echo $rinci['jumlah']; ?> Pcs</td>
						<td><?php echo rupiah($rinci['total']); ?></td>				
					</tr>
				<?php } ?>
				</tbody>
			</table>
		</div>
	</div>
	<div class="row-md-5" style="padding-top: 1rem;">
		<button class="btn btn-secondary" onclick="PrintDiv();"><span class="ti-printer"></span></button>&emsp;
		<button class="btn btn-secondary"><span class="ti-import"></span></button>
	</div>
</section>
			
<script type="text/javascript">
	function PrintDiv() {    
 var divToPrint = document.getElementById('tabp');
 var nota =document.getElementById('nota').value;
 window.document.write('<html><body onload="window.print()">' + divToPrint.innerHTML + '</html>');
  window.document.close();
    //direct after print !!//
   window.setTimeout(function () {
    location.href = "info_pembelian.php?id="+nota;
    }, 2000);
      }

</script>
 <?php 
 include "footer.php";
  ?>