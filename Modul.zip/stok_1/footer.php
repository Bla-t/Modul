
</main>
</div>
</body> 
<script>
$(document).ready(function(){
	//search guide.!!
  $("#input").on("keyup", function() {
    var value = $(this).val().toLowerCase();
    $("#table tr").filter(function() {
      $(this).toggle($(this).text().toLowerCase().indexOf(value) > 10)
    });
  });
  //move to uppercase.!!
   $("input[type=text]").keyup(function () {  
            $(this).val($(this).val().toUpperCase());  
        });
  $('[data-toggle="tooltip"]').tooltip();   
});

</script>

</html>