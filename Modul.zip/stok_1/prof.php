
<?php 
include "header.php";
 ?>
 <section class="recent">
 	<div class="activity-card">
 		<div class="form-inline" style="border-bottom: 2px solid #D5D8DC;">
	 		<h4><img src="../gamb_user/<?php echo $gam; ?>" class="profgam" alt="<?php echo $icon_user;?>">Profil</h4>
 		</div>
 		<?php 
 			include "config.php";
 			$prof = mysqli_query($conn,"SELECT * FROM `dat_uss` WHERE `id` = '$iduser'") or die(mysqli_error($conn));
 			while ($cek = mysqli_fetch_array($prof)) {
 		 ?>
 		<div class="row">
 			<div class="col-md-6">
		 		<div class="form-group">
		 			<label for="user">Username</label>
		 			<input type="text" name="Username_user" id="user" class="form-control form-control-sm" value="<?php echo $cek['username'];?>">
		 		</div>
		 		<div class="form-group">
		 			<label for="nama">Nama</label>
		 			<input type="text" name="nama_user" id="nama" class="form-control form-control-sm" value="<?php echo $cek['nama']; ?>">
		 		</div>
		 		<div class="form-group">
		 			<label for="pasword">Password | Rubah Password</label>
		 			<input type="password" name="Password_user" id="pasword" class="form-control form-control-sm" value="<?php echo $cek['password']; ?>">
		 		</div>
		 		<div class="form-group">
		 			<label for="file_gambars">Ganti Gambar</label>
			 		<div class="custom-file" id="file_gambar">
					    <input type="file" class="custom-file-input form-control-sm" id="customFile" name="gambar_file">
					    <label class="custom-file-label" for="customFile">Cari Gambar</label>
					</div>
				</div>
		 	</div>
			 <div class="col-md-6">
		 		<div class="form-group">
		 			<label for="type">Bagian</label>
		 			<input type="text" name="" id="type" class="form-control form-control-sm" readonly value="<?php echo $cek['type']; ?>">
		 		</div>
		 		<div class="form-group">
		 			<label for="levl">level user</label>
		 			<input type="text" name="" id="levl" class="form-control form-control-sm" readonly value="<?php echo $cek['levl']; ?>">
		 		</div>
		 		<div class="form-group">
		 			<label for="password_baru">Verifikasi Password</label>
		 			<input type="password" name="password_baru" id="password_baru" class="form-control form-control-sm">
		 		</div>
			<?php } ?>
	 		</div>
		 		<button class="btn btn-warning">Batal</button>&emsp;
		 		<button class="btn btn-danger" id="simpan_profil">Simpan</button>
 		</div>
 	</div>
 </section>
<script>
	// Add the following code if you want the name of the file appear on select
	$(".custom-file-input").on("change", function() {
	  var fileName = $(this).val().split("\\").pop();
	  $(this).siblings(".custom-file-label").addClass("selected").html(fileName);
	});


	$(function(){
		$("#simpan_profil").click(function(){
			var pass1 = $("#pasword").val();
			var pass2 = $("#password_baru").val();
			if (pass1 != pass2) {
				alert("Password / Kata sandi Harus sama..!");
				return false;
			}
			else if (pass1 == pass2) {
				confirm("anda Yakin.!!??");
				return false;

			}
				return true;
		});
	});
</script>
 <?php 
include "footer.php";
  ?>