<?php 	
	include "header.php";
?>
	<h3>DATA BARANG</h3>
		<section class="recent">			
            <div class="activity-card">            	         	
            	<?php             		

            		$TOT= mysqli_query($conn,"SELECT COUNT(id_barang) AS 'tot' FROM `stok_databarang` WHERE `milik` = '$milik'");
					$has = mysqli_fetch_assoc($TOT);
            	 ?>
                <h4> Data barang <kbd><?php echo $has['tot']; ?></kbd></h4>
                <div class="col-md-5">
	                <div class="input-group mb-3">
					    <input type="text" class="form-control" id="input" placeholder="cari">
					    <div class="input-group-append">
					      <span class="input-group-text ti-search"></span>
					    </div>
					</div>
				</div>				
                <div class="table-responsive">
                <table>
                    <thead>
                        <tr>
                            <th>No.</th>
                            <th>SKU</th>
                            <th>Nama</th>
                            <th>Harga beli</th>
                            <th>Harga Jual</th>
                            <th>Kategori</th>
                            <th>Merk</th>
                            <th>Keterangan</th>
                            <th>acc</th>
                            <th>Aksi</th>
                            <th></th>
                        </tr>
                    </thead>
                    <?php 
                    	$n=1;
                    	$isi=mysqli_query($conn," SELECT * FROM `stok_databarang` WHERE `milik`='$milik'")or die(mysqli_error($conn));
                    	while($data=mysqli_fetch_array($isi)){

                     ?>
	                <form method="POST" action="aksi/aksi_data-barang.php">
                    <tbody id="table">
                        <tr>
                            <td><?php echo '.'.$n++; ?></td>
                            <td><?php echo $data['id_barang'];?></td>
                            <td><?php echo $data['nama_barang'];?></td>
                            <td><?php echo rupiah($data['harga_beli']);?></td>
                            <td><?php echo rupiah($data['harga_jual']);?></td>
                            <td><?php echo $data['kategori'];?></td>
                            <td><?php echo $data['merk'];?></td>
                            <td><?php echo $data['keterangan'];?></td>
                            <td><?php echo $data['acc'];?></td>
                            <td><a class="btn btn-warning btn-sm" name="rubsh" href="rubah_kategori.php?id=<?php echo $data['id']?>" id="rubah"><span class="ti-pencil-alt"></span></a>
                            </td>
                            <td><button type="submit" class="btn btn-danger btn-sm" name="haps" id="hapus" value="<?php echo $data['id']?>"><span class="ti-trash"></span></button>
				            </td>				            
                        </tr>
                    <?php } ?>
                    </tbody>
	                </form>
                </table>
                </div>
            </div>
            <div class="summary">
                <div class="summary-card"><br>
                   <a class="btn btn-info" href="tambah-jenisbarang.php"><span class="ti-pencil"></span> Tambah Barang</a> 
                </div>
            </div>
        </section>

        <script type="text/javascript">
        	$(document).ready(function(){
        		$("#hapus").click(function(){
        			if (confirm("Anda Yakin..!?")) {

        			}
        			else{ return false;}
        		});
        	});
        </script>


	<!-- <form method="POST" action="">
		<div class="col-md-12">
			<div class="form-row">
			   <div class="col">
			      <label for="id_barang">id barang</label>
			      <input type="text" class="form-control isi" id="id_barang" name="" required>
			    </div>
			    <div class="col">
			      <label for="a"> Jenis</label>
			      <input type="text" class="form-control isi" id="a" name="" required>
			    </div>			    
			  </div>
			<div class="form-row">
				<div class="col">
					<label for="nama Barang">Nama Barang</label>
					<input id="nama Barang" class="form-control" name="" required>
				</div>
				<div class="col">
					<label for="harga_jual">Harga Jual</label>
					<input id="harga_jual" class="form-control" name="" required>
				</div>
			</div>
			<div class="form-row">
				<div class="col">
					<label for="harga_beli">Harga Beli</label>
					<input id="harga_beli" class="form-control" name="" required>
				</div>
				<div class="col">
					<label for="Kategori">Kategori</label>
					<input id="Kategori" class="form-control"name="" required>
				</div>				
				<div class="col">
					<label for="tombol1"></label>
					<button id="tombol1" class="btn btn-info" style="margin-top: 2rem;"> Tambah Kategori</button>
				</div>
			</div>
			<div class="form-row">
				<div class="col">
					<label for="Keterangan">Keterangan</label>
					<textarea id="Keterangan" class="form-control"></textarea>
				</div>
			</div>
			<br/>
			<div class="form-inline">
				<button type="submit" class="btn btn-primary mb-2 mr-sm-2">Simpan</button>
				<a type="button" class="btn btn-success mb-2 mr-sm-2" href="index.php">Batal</a>					
			</div>					
		</div>
	</form> -->


	<?php include "footer.php" ?>