<?php include "header.php" ?>
		<h2 class="dash-title"> Dashboard</h2>
		<div class="dash-cards">
			<div class="card-single bg-warning">
				<div class="card-body">
					<?php  
						$jumlah= mysqli_query($conn,"SELECT SUM(stok) AS 'jum' FROM `stok_databarang` WHERE `milik` = '$milik' AND `stok` != '0'") or die(mysqli_error($conn));

						//$jumlah_servis= mysqli_query($conn,"SELECT SUM(stok) AS 'jum_servis' FROM `` WHERE `milik` = '$milik'") or die(mysqli_error($conn));


						$tot_databarang = mysqli_fetch_assoc($jumlah);

						

						if (empty($tot_databarang['jum'])) {$jum = "0";}
						else{$jum = $tot_databarang['jum'];}

					 ?>
					<span class="ti-briefcase"></span>
					<div>
						<h3>stok</h3>
						<h4><?php echo $jum.', Pcs';?></h4>						
					 </div>
				</div>
				<div class="card-footer">
					<a href=""><span class="ti-angle-double-right"></span>Lihat</a>
				</div>
			</div>
			<div class="card-single bg-danger">
				<div class="card-body">
					<span class="ti-lock"></span>
					<div>
						<?php 
							/*$total_nota_pakai= mysqli_query($conn,"SELECT SUM() AS 'tot_not' FROM `` WHERE `` ")or die(mysqli_error($conn));
							$totnota= mysqli_fetch_assoc($total_nota_pakai);*/
						 ?>
						<h3><?php 
								if ($milik == "ARM") {
									echo "Pemakaian";
									}
								else{
									echo"Distribusi";
								}
						  ?></h3>
						<h4><?php //echo $totnota; ?> Nota</h4>
					 </div>
				</div>
				<div class="card-footer">
					<a href=""><span class="ti-angle-double-right"></span>Lihat</a>
				</div>
			</div>
			<div class="card-single bg-info">
				<div class="card-body">
					<span class="ti-clipboard"></span>
					<div>
						<h3>Pembelian</h3>
						<h4><?php echo rupiah("178");?></h4>
					 </div>
				</div>
				<div class="card-footer">
					<a href=""><span class="ti-angle-double-right"></span>Lihat</a>
				</div>
			</div>
			<div class="card-single bg-success">
				<div class="card-body">
					<span class="ti-settings"></span>
					<div>
						<h3>Servis</h3>
						<h4><?php echo "78 Pcs";?></h4>
					 </div>
				</div>
				<div class="card-footer">
					<a href="dat_brg_serv.php"><span class="ti-angle-double-right"></span>Lihat</a>
				</div>
			</div>
		</div>
			<?php     	
        		$TOT= mysqli_query($conn,"SELECT COUNT(id_barang) AS 'tot' FROM `stok_databarang` WHERE `milik` = '$milik'");
				$has = mysqli_fetch_assoc($TOT);
        	 ?>
		<section class="recent">
			<div class="activity-card">
				<h3>Daftar stok <kbd><?php echo $has['tot']; ?></kbd></h3>
				<div class="col-md-5">
	                <div class="input-group mb-3">
					    <input type="text" class="form-control" id="input" placeholder="cari">
					    <div class="input-group-append">
					      <span class="input-group-text ti-search"></span>
					    </div>
					</div>
				</div>
				<div class="table-responsive table-hover" id="tabp">
				<table>
					<thead>
						<tr>
							<th>No.</th>
							<th>SKU</th>
							<th>Nama</th>
							<th>merk</th>
							<th>Kategori</th>
							<th>harga Beli</th>
							<?php if($milik == 'GA'){ echo('<th>harga jual</th>');}else if($milik == 'ARM'){}?>
							<th>Jumlah Stok</th>
							<!--<?php// if($milik == 'GA'){ echo('<th>Jumlah Perbaikan</th>');}else if($milik == 'ARM'){}?>-->

						</tr>
					</thead>
					<tbody id="table">
						<?php 
	                    	$n=1;
	                    	$isi=mysqli_query($conn," SELECT * FROM `stok_databarang` WHERE `milik`='$milik' ORDER BY `kategori` ASC")or die(mysqli_error($conn));
	                    	while($data=mysqli_fetch_array($isi)){

	                     ?>
						<tr>
							<td><?php echo '.'.$n++; ?></td>
							<td><?php echo $data['id_barang']; ?></td>
							<td><?php echo $data['nama_barang']; ?></td>
							<td><?php echo $data['merk'] ?></td>
							<td><?php echo $data['kategori'];?></td>
							<td><?php echo rupiah($data['harga_beli']); ?></td>
							<?php if($milik == 'GA'){ echo('<td>'.rupiah($data['harga_jual']).'</td>');}else if($milik == 'ARM'){}?>
							<td><?php echo $data['stok']; ?> pcs</td>
							<!--<?php// if($milik == 'GA'){ echo('<td>'.$data['status'].' Pcs</td>');}else if($milik == 'ARM'){}?>-->
							
						</tr>
						<?php } ?>
						<tr>
							<td></td>
							<td></td>
							<td></td>
							<td></td>
							<td></td>
							<td></td>
							<?php// mysqli_query($conn,"SELECT SUM() AS  AND ") or die(mysqli_error($conn)); ?>
							<td></td>							
						</tr>
					</tbody>
				</table>
				</div>
			</div>
			<div class="summary">
				<div class="summary-card">
					<div class="card-body">
						<button class="btn btn-secondary" onclick="PrintDiv();" id="print"><span class="ti-printer"> Print</span></button>&emsp;
						<button class="btn btn-secondary" id="import"><span class="ti-import"></span> Import</button>
					</div>
				</div>
			</div>
			 <script type="text/javascript">     
				    function PrintDiv() {    
					 var divToPrint = document.getElementById('tabp');
					 window.document.write('<html><body onload="window.print()">' + divToPrint.innerHTML + '</html>');
					  window.document.close();
					  window.location.href = "location: index.php";
					    //direct after print !!//
					   window.setTimeout(function () {
					    location.href = "index.php";
					    }, 1000);
					      }
			 </script>
		</section>
<?php include "footer.php" ?>
	