<?php 
include "header.php";
 ?>
<section class="recent">
	<?php 
	$nota_tempel = $_GET['id'];
	$nota = substr($_GET['id'], 0, 18);
	$num=1;
	$query= mysqli_query($conn, "SELECT * FROM `stok_isipakai` WHERE `nota` = '$nota'") or die(mysqli_error($conn));
	?>
	<input type="hidden" id="nota" value="<?php echo $nota_tempel; ?>">
	<div class="activity-card">
		<div class="form-inline" style="border-bottom: 2px solid #bbbb;">			
			<h3>Nota <?php if($milik == "ARM"){ echo"Pemakaian";} else {echo"Distribusi";} ?> : <?php echo $nota; ?> |</h3>
			<a class="btn btn-info btn-sm" href="lap_pemakaian.php" >Kembali</a>
		</div>	
		<?php
			$npl = substr($nota_tempel, 18, 11);
			$nop_pol = mysqli_query($conn," SELECT * FROM `stok_member` WHERE `nopol` = '$npl'") or die(mysqli_error($conn));
			while ($nopol = mysqli_fetch_array($nop_pol)){

			 ?>
			 <div id="print">
		<div class="row" style="border-bottom: 1px solid #cccc;">
			<div class="col">
				<p><span class="font-weight-bold">No. Nota : </span><?php echo $nota; ?></p>
				<p><span class="font-weight-bold">No. Mesin : </span><?php echo $nopol['nomesin']; ?></p>
			</div>
			<div class="col">
				<p><span class="font-weight-bold">No.Polisi :</span> <?php echo $nopol['nopol']; ?></p>
				<p><span class="font-weight-bold">Jenis :</span> <?php echo $nopol['jenis']; ?></p>
			</div>
		</div>
	<?php } ?>
		<div class="table-responsive" id="tabp">
			<table>
				<thead>
					<tr>
						<th>No.</th>
						<th>SKU</th>
						<th>Nama</th>
						<th>jumlah</th>
						<th>Total</th>				
					</tr>
				</thead>
				<tbody>
					<?php while($rinci=mysqli_fetch_array($query)){ ?>
					<tr>
						<td><?php echo $num++; ?></td>
						<td><?php echo $rinci['kode_barang']; ?></td>
						<td><?php echo $rinci['nama']; ?></td>
						<td><?php echo $rinci['jumlah']; ?> Pcs</td>
						<td><?php echo rupiah($rinci['harga']); ?></td>				
					</tr>
				<?php } ?>
				</tbody>
			</table>
		</div>
		</div>
	</div>
	<div class="row-md-5" style="padding-top: 1rem;">
		<button class="btn btn-secondary" onclick="PrintDiv();"><span class="ti-printer"></span></button>&emsp;
		<button class="btn btn-secondary"><span class="ti-import"></span></button>
	</div>
</section>
			
<script type="text/javascript">
	function PrintDiv() {    
 var divToPrint = document.getElementById('print');
 var nota =document.getElementById('nota').value;
 window.document.write('<html><body onload="window.print()">' + divToPrint.innerHTML + '</html>');
  window.document.close();
    //direct after print !!//
   window.setTimeout(function () {
    location.href = "info_pakai.php?id="+nota;
    }, 2000);
      }

</script>
 <?php 
 include "footer.php";
  ?>