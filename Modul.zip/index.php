<!DOCTYPE html>
<html>
<head>
	<title> Modul_Oprasional PT. BARAKA SARANA TAMA
	</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="shortcut icon" type="image/png" href="gamb/gam.png"/>
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
  <script type="text/javascript" src="https://code.jquery.com/jquery-3.3.1.min.js"></script>
  <style type="text/css">
  	
  	.container-fluid{
  		margin-top: 150px;
  	}
  	.lab,.display-4 {
  		color: cyan;
  	}
  	.btn-dark{
  		background-color: #E16A00;
  	}
  	body{
  		background: url('gamb/1400x800_Inspiration_cd7ugq.jpg')fixed;
  		opacity: 90%;  		
  	}
  </style>
</head>
<body>
<div class="container-fluid">
	<div class="row">		
		<div class="col-md-4 offset-md-4">
			<div class="card bg-dark">
				<div class="card-body">
					<?php
						if (isset($_GET['pesan'])) {
	        				if ($_GET['pesan'] == "ok") {
	        					
	        		        echo('
					          <div class="alert alert-success alert-dismissible fade show text-center">
					              <button type="button" class="close" data-dismiss="alert">&times;</button>
					              <strong>Silahkan masuk.!</strong>
					          </div>');	        	
					          header("location:home.php");	        
					        }
						     else if ($_GET['pesan'] == "gagal") {
	        
					        echo('
					          <div class="alert alert-danger alert-dismissible fade show text-center">
					              <button type="button" class="close" data-dismiss="alert">&times;</button>
					              <strong>Username atau Password</strong> tidak sesuai.!
					          </div>');
					        }
						    else if ($_GET['pesan'] == "ot") {
	        
					        echo('
					          <div class="alert alert-warning alert-dismissible fade show text-center">
					              <button type="button" class="close" data-dismiss="alert">&times;</button>
					              Anda telah <strong>Log Out. . !</strong>
					          </div>');
					        }

				        }
					        ?>
					<h2 class="display-4 text-center font-weight-normal"> Form Login</h2>
					<form method="POST" action="log_ins.php">
						<div class="form-group">
							<label class="lab">Username :</label>
							<input class="form-control" type="text" name="user" placeholder="Username">
						</div>
						<div class="form-group">
							<label class="lab">Password :</label>
							<input class="form-control" type="Password" name="pass" placeholder="Password">
						</div>
						<div class="form-row">
							<label></label>
							<div class="col-md-6 offset-md-3">
							<button class="btn btn-dark btn-block" id=""> Log in</button>
							</div>
						</div>						
					</form>
				</div>
			</div>
		</div>
	</div>
</div>
</body>
</html>